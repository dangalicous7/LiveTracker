package com.example.livetracker

import android.annotation.SuppressLint
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.renderscript.Sampler.Value
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.location.*
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*
import kotlinx.coroutines.*
import java.util.*


class MainActivity : AppCompatActivity() {

    //A connection to the Google Play location API
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    //Handles to the UI widgets in the layout
    var coordinates: String? = null
    lateinit var search: FloatingActionButton

    //Geocoder will handling the andress lookup
    lateinit var  geocoder : Geocoder

    //this will be used to pass the current coordinates to Geocoder
    var latlong: Location? = null
    var addresses : List<Address> = emptyList()
    var hard_copy = mutableListOf<LocationItem>()
    private var adapter = LocationListAdapter()
    private var recyclerView: RecyclerView? = null

    var date = Calendar.getInstance().time
    var times = mutableListOf<String>()

    private lateinit var ref : DatabaseReference

    //Get the last known location and paint it to the textView
    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //Geocoder will handling the andress lookup
        geocoder = Geocoder(this, Locale.getDefault())
        setContentView(R.layout.activity_main)
        search = findViewById(R.id.fab)

        ref = FirebaseDatabase.getInstance().getReference("Locations")


        //Create a location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        //get the last location identified. Also, set a listener that updates the
        //R.id.coordinates text when the location is found (on Success)
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location : Location? ->
                //we are using the let scope to avoid writing the if statements for this type of assignment
                location?.let{latlong=it
                    //When the search address button is clicked...
                    search.setOnClickListener{
                        addresses = geocoder.getFromLocation(location.latitude, location.longitude,
                            1) as List<Address>
                        date = Calendar.getInstance().time

                        val id = ref.push().key!!
                        val db_item = LocationItem(addresses.get(0).latitude.toString() + ", "
                                + addresses.get(0).longitude.toString(),
                            addresses.get(0).getAddressLine(0), date.toString())
                        ref.child(id).setValue(db_item)

                        hard_copy.add(db_item)
                        adapter.setLocations(hard_copy)
                    }}
            }

        recyclerView = findViewById<RecyclerView>(R.id.location_list)
        recyclerView?.adapter = adapter
        recyclerView?.layoutManager = LinearLayoutManager(this)


        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (snap in snapshot.children) {
                        val data = snap.getValue(LocationItem::class.java)
                        if (data != null) {
                            hard_copy.add(data)
                        }
                    }
                    adapter.setLocations(hard_copy)
                }
            }
            override fun onCancelled(error: DatabaseError) {
            }
        })

        //This will let the user know when the location was not able to be found.
        fusedLocationClient.lastLocation
            .addOnFailureListener {
                coordinates="Failed to get location"
            }

        //setting up the callback
        var locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                locationResult ?: return
                for (location in locationResult.locations){
                    coordinates="Lat:${location?.latitude} Long:${location?.longitude}"
                }
            }
        }
        //passing the `locationCallback` object and the `locationRequest` to the location client
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null)
    }

    // A LocationRequest controls the process of asking for a new location.
    // the timings are in milliseconds

    val locationRequest = LocationRequest.create()?.apply {
        interval = 1000
        fastestInterval = 500
        priority = LocationRequest.PRIORITY_HIGH_ACCURACY
    }


    /**
     * The adapter for the RecyclerView. Provides the list of items to be displayed there.
     */
    inner class LocationListAdapter() : RecyclerView.Adapter<LocationListAdapter.LocationViewHolder>() {

        //a list of the movie items to load into the RecyclerView
        private var modified = emptyList<LocationItem>()

        internal fun setLocations(locations: List<LocationItem>) {
            this.modified = locations.toList()
            notifyDataSetChanged()
        }


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LocationViewHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.card_view, parent, false)
            return LocationViewHolder(v)
        }

        override fun onBindViewHolder(holder: LocationViewHolder, position: Int) {
            holder.view.findViewById<TextView>(R.id.latlong).text = modified[position].latlong

            holder.view.findViewById<TextView>(R.id.address).text = modified[position].address

            holder.view.findViewById<TextView>(R.id.timestamp).text = modified[position].timestamp

            holder.itemView.setOnClickListener {
                val Uri = Uri.parse("geo:0,0?q=" + Uri.encode(modified[position].address))
                val Intent = Intent(Intent.ACTION_VIEW, Uri)
                Intent.setPackage("com.google.android.apps.maps")
                startActivity(Intent)
            }
        }

        override fun getItemCount(): Int {
            return modified.size
        }

        inner class LocationViewHolder(val view: View) : RecyclerView.ViewHolder(view),
            View.OnClickListener {
            override fun onClick(view: View?) {
                Log.d("retrofit_demo", "list tap ")
                if (view != null) {
                    //Do some stuff here after the tap
                }
            }
        }
    }
}
