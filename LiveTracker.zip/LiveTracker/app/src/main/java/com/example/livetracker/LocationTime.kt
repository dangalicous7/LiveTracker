package com.example.livetracker

data class LocationItem(val latlong: String? = "", val address: String? = "", val timestamp: String? = "")